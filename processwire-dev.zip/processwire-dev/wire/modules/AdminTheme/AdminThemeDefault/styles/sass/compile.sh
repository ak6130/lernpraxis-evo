sass --style=compressed --no-source-map main-warm.scss:../main-warm.css
sass --style=compressed --no-source-map main-classic.scss:../main-classic.css
sass --style=compressed --no-source-map main-futura.scss:../main-futura.css
sass --style=compressed --no-source-map main-modern.scss:../main-modern.css
