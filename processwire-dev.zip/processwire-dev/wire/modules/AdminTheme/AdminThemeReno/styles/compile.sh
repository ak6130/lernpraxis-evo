sass --no-source-map --style=compressed main.scss:main.css
sass --no-source-map --style=compressed classic.scss:classic.css
sass --no-source-map --style=compressed blue.scss:blue.css
sass --no-source-map --style=compressed blue.scss:blue.css
