<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Regular Uikit 3.x site/blog profile", 
	'summary' => "This is a simple/regular blog site profile that uses Uikit 3 on the front-end and demonstrates several features new to ProcessWire 3.x.", 
	'screenshot' => "screen_shot_2017-01-27_at_1_30_19_pm.png"
);
