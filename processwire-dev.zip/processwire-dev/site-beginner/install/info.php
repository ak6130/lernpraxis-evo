<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Default (Beginner Edition)", 
	'summary' => "A minimal responsive site profile that serves as a good starting point for new sites or for learning about ProcessWire. Focuses on using the easiest to understand template concepts for new users.", 
	'screenshot' => "screenshot.png"
	);
